import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

interface CookieOptions {
  path?: string;
  expires?: Date;
  maxAge?: number;
  domain?: string;
  secure?: boolean;
  httpOnly?: boolean;
  sameSite?: "strict" | "lax" | "none";
}

export async function createClient() {
  const cookieStore = await cookies();

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet: { name: string; value: string; options?: CookieOptions }[]) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            );
          } catch {
            // The `setAll` method was called from a Server Component.
            // This can be ignored if you have middleware refreshing user sessions.
          }
        },
      },
    }
  );

  // ملاحظة أمنية (Milestone 3 Closure، 2026-08-09):
  // كان هذا الملف يستدعي RPC "set_tenant_id" لضبط app.current_tenant_id عبر set_config،
  // بافتراض أن سياسات RLS تعتمد عليه. تم التحقق مباشرة من pg_policies الحية: لا توجد
  // ولا سياسة واحدة تقرأ app.current_tenant_id. عزل المستأجر يتم فعليًا عبر الدالة
  // get_current_tenant_id() SECURITY DEFINER، التي تعتمد بشكل مستقل على:
  // JWT app_metadata → JWT user_metadata → fallback مباشر لـ clinic_users عبر auth.uid().
  // لذلك كان الاستدعاء no-op فعليًا. تمت إزالته لتفادي كود مضلّل أمنيًا.
  // إن ظهرت حاجة مستقبلية لسياق tenant عبر current_setting، يجب أولاً إضافة سياسات
  // RLS فعلية تقرأه، ثم إعادة تفعيل هذا الاستدعاء عن قصد وموثّق.

  return supabase;
}
