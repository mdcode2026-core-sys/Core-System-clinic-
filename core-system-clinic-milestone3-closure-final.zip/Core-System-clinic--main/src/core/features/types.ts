// src/core/features/types.ts
// Feature Engine — Type Definitions
// Mirrors src/core/permissions/types.ts to keep Permission Engine and
// Feature Engine structurally symmetric (see EXECUTION_PLAN §5 — Engineering Decisions).
//
// Milestone 3 Closure (2026-08-09): طُبّعت الاتفاقية على lowercase حصرًا، حسب قرار
// المالك النهائي. المفاتيح القديمة بأسلوب UPPERCASE (ADVANCED_ANALYTICS, AUDIT_TRAIL,
// INVENTORY_MODULE, MULTI_BRANCH, WHATSAPP_AUTOMATION) أُزيلت من هذا الاتحاد لأنها لم
// تكن مستخدَمة فعليًا في أي كود تطبيقي (تحقق مباشر: grep عبر src بالكامل) باستثناء
// ADVANCED_ANALYTICS التي كانت تُستخدم في widgetRegistry.ts وتم نقلها إلى "analytics".
// الصفوف المقابلة القديمة في جدول feature_flags الحي أُزيلت بمigration مرافقة.
export type FeatureModuleKey =
  | "patients"
  | "agenda"
  | "queue"
  | "billing"
  | "followup"
  | "inventory"
  | "analytics"
  | "reports";
