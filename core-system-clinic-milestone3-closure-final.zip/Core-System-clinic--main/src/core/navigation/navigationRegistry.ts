// src/core/navigation/navigationRegistry.ts
// Package 3.0.2 — Navigation Registry: single source of truth for all dashboard routes
// and their required permissions. Additive only; does not replace permissionMatrix.ts.

import type { Permission } from "@/core/permissions/types";
import type { FeatureModuleKey } from "@/core/features/types";
import {
  LayoutDashboard,
  Users,
  CalendarDays,
  ListOrdered,
  FileText,
  Package,
  FileBarChart,
  BarChart3,
  PhoneCall,
  Settings,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

export interface NavItem {
  href: string;
  label: string;
  labelAr: string;
  icon: LucideIcon;
  requiredPermission: Permission | null; // null = always visible to any authenticated user
  // Milestone 3 Closure: ربط صريح بمفتاح الميزة الموحّد (lowercase convention).
  // null = عنصر أساسي غير مرتبط بأي علم ميزة (Dashboard/Settings)، يظل خاضعًا
  // للصلاحيات فقط. أي عنصر آخر يُخفى إن كانت الميزة معطّلة حتى لو توفرت الصلاحية.
  featureKey: FeatureModuleKey | null;
}

/**
 * Canonical navigation registry for the Unified Workspace.
 * Order determines display order in both desktop sidebar and mobile Sheet drawer.
 *
 * New modules (Inventory, Reports, Follow-up) are registered here now
 * but will remain hidden for roles lacking their permissions until
 * their Phase 3.1 packages ship.
 */
export const navigationRegistry: NavItem[] = [
  {
    href: "/",
    label: "Dashboard",
    labelAr: "لوحة التحكم",
    icon: LayoutDashboard,
    requiredPermission: null, // always visible
    featureKey: null, // Milestone 3 Closure
  },
  {
    href: "/patients",
    label: "Patients",
    labelAr: "المرضى",
    icon: Users,
    requiredPermission: "patients:read",
    featureKey: "patients", // Milestone 3 Closure
  },
  {
    href: "/agenda",
    label: "Agenda",
    labelAr: "الأجندة",
    icon: CalendarDays,
    requiredPermission: "agenda:read",
    featureKey: "agenda", // Milestone 3 Closure
  },
  {
    href: "/queue",
    label: "Queue",
    labelAr: "الطابور",
    icon: ListOrdered,
    requiredPermission: "sessions:read",
    featureKey: "queue", // Milestone 3 Closure
  },
  {
    href: "/invoices",
    label: "Invoices",
    labelAr: "الفواتير",
    icon: FileText,
    requiredPermission: "invoices:read",
    featureKey: "billing", // Milestone 3 Closure
  },
  {
    href: "/inventory",
    label: "Inventory",
    labelAr: "المخزون",
    icon: Package,
    requiredPermission: "inventory:read",
    featureKey: "inventory", // Milestone 3 Closure
  },
  {
    href: "/reports",
    label: "Reports",
    labelAr: "التقارير",
    icon: FileBarChart,
    requiredPermission: "reports:read",
    featureKey: "reports", // Milestone 3 Closure
  },
  {
    href: "/analytics",
    label: "Analytics",
    labelAr: "التحليلات",
    icon: BarChart3,
    requiredPermission: "analytics:read",
    featureKey: "analytics", // Milestone 3 Closure
  },
  {
    href: "/follow-up",
    label: "Follow-up",
    labelAr: "المتابعة",
    icon: PhoneCall,
    requiredPermission: "followup:read",
    featureKey: "followup", // Milestone 3 Closure
  },
  {
    href: "/settings",
    label: "Settings",
    labelAr: "الإعدادات",
    icon: Settings,
    requiredPermission: "settings:read",
    featureKey: null, // Milestone 3 Closure
  },
];

/**
 * Helper: resolve the required permission for a given pathname.
 * Returns undefined if the route is not registered (should not happen for valid routes).
 */
export function getRequiredPermission(pathname: string): Permission | null | undefined {
  // Exact match first
  const exact = navigationRegistry.find((n) => n.href === pathname);
  if (exact) return exact.requiredPermission;

  // Sub-route fallback: e.g. /invoices/123 → /invoices
  const parent = navigationRegistry.find(
    (n) => n.href !== "/" && pathname.startsWith(n.href + "/")
  );
  if (parent) return parent.requiredPermission;

  return undefined;
}
