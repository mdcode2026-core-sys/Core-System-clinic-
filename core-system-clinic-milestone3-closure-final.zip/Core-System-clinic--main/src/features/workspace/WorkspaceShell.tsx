"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { LogOut, Menu, X } from "lucide-react";
import { navigationRegistry } from "@/core/navigation/navigationRegistry";
import { usePermissions } from "@/core/permissions/usePermissions";
import { useFeatureFlags } from "@/core/features/useFeatureFlags";
import type { FeatureModuleKey } from "@/core/features/types";
import { createClient } from "@/infrastructure/supabase/client";
import { cn } from "@/shared/utils/cn";

interface WorkspaceShellProps {
  children: React.ReactNode;
  user: { email?: string } | null;
}

// Milestone 3 Closure: قائمة ثابتة مشتقة من navigationRegistry (وليست مكتوبة يدويًا
// مرتين) لتفادي انحراف مستقبلي بين التنقل وأعلام الميزات المطلوبة.
const NAV_FEATURE_KEYS = Array.from(
  new Set(
    navigationRegistry
      .map((item) => item.featureKey)
      .filter((key): key is FeatureModuleKey => key !== null)
  )
);

export function WorkspaceShell({ children, user }: WorkspaceShellProps) {
  const pathname = usePathname();
  const router = useRouter();
  const { hasPermission } = usePermissions();
  const { isFeatureEnabled, isLoading: featuresLoading } = useFeatureFlags(NAV_FEATURE_KEYS);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const supabase = createClient();

  // Milestone 3 Closure — الفجوة المؤكدة سابقًا: كانت الوحدة تظهر بالاعتماد على
  // الصلاحية فقط حتى لو كانت الميزة معطّلة تينانتيًا. الآن: صلاحية AND ميزة معًا.
  // أثناء تحميل الأعلام (featuresLoading) نُبقي العنصر مخفيًا مؤقتًا بدل وميض ظهور/اختفاء.
  const filteredNav = navigationRegistry.filter((item) => {
    const permissionOk = item.requiredPermission === null || hasPermission(item.requiredPermission);
    if (!permissionOk) return false;
    if (item.featureKey === null) return true; // Dashboard/Settings: غير مرتبطة بعلم ميزة
    if (featuresLoading) return false;
    return isFeatureEnabled(item.featureKey);
  });

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  };

  return (
    {/* Milestone 3 Closure: dir محذوف من هنا عمدًا — يُدار مركزيًا على <html> عبر
        DirectionProvider (src/shared/i18n/DirectionProvider.tsx) ويتوارث تلقائيًا. */}
    <div className="flex h-screen w-full bg-gray-50">
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={cn(
          "fixed inset-y-0 right-0 z-50 w-64 transform bg-white shadow-lg transition-transform duration-200 ease-in-out lg:static lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "translate-x-full lg:translate-x-0"
        )}
      >
        <div className="flex h-full flex-col">
          <div className="flex items-center justify-between border-b px-6 py-4">
            <Link href="/" className="text-xl font-bold text-blue-600">
              ClinicSaaS™
            </Link>
            <button
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden"
              aria-label="إغلاق القائمة"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
            {filteredNav.map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setSidebarOpen(false)}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                    isActive
                      ? "bg-blue-50 text-blue-700"
                      : "text-gray-700 hover:bg-gray-100 hover:text-gray-900"
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  <span>{item.labelAr}</span>
                </Link>
              );
            })}
          </nav>
        </div>
      </aside>

      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex items-center justify-between border-b bg-white px-4 py-3 lg:px-6">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden"
              aria-label="فتح القائمة"
            >
              <Menu className="h-5 w-5 text-gray-600" />
            </button>
            <h1 className="text-lg font-semibold text-gray-900">
              مساحة العمل
            </h1>
          </div>

          <div className="flex items-center gap-4">
            <span className="hidden text-sm text-gray-600 sm:inline">
              {user?.email}
            </span>
            <button
              onClick={handleSignOut}
              className="flex items-center gap-1.5 rounded-md bg-gray-100 px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-200"
            >
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">تسجيل الخروج</span>
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}

export default WorkspaceShell;
