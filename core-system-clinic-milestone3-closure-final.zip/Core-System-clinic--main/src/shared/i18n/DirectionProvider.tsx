"use client";
// src/shared/i18n/DirectionProvider.tsx
// مزوّد اتجاه/لغة موحّد على مستوى الجذر (Milestone 3 Closure — بند 10 RTL/LTR).
// يحل محل أي حل جزئي على مستوى المكوّن الواحد. يضبط <html dir="rtl|ltr" lang="ar|en">
// فعليًا في DOM عبر useEffect، ويوفر Context لبقية التطبيق (مثل تبديل اللغة مستقبلاً
// من Tenant Administration Center في Milestone 2).
//
// الافتراضي الحالي: "ar" (rtl) لأن كل بيانات العيادة الأساسية (اسم العيادة، أسماء
// المرضى، التنقل) ثنائية اللغة بالفعل مع أولوية عربية في الحقول (_ar) والعملة
// الافتراضية (JOD) والمنطقة الزمنية الافتراضية (Asia/Amman). قابل للتبديل لاحقًا
// عبر تفضيل مستخدم/تينانت حقيقي دون تغيير هذه البنية.

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type AppLocale = "ar" | "en";
export type AppDirection = "rtl" | "ltr";

interface DirectionContextValue {
  locale: AppLocale;
  direction: AppDirection;
  setLocale: (locale: AppLocale) => void;
}

const DIRECTION_BY_LOCALE: Record<AppLocale, AppDirection> = {
  ar: "rtl",
  en: "ltr",
};

const STORAGE_KEY = "core-system-locale";

const DirectionContext = createContext<DirectionContextValue | null>(null);

export function DirectionProvider({
  children,
  defaultLocale = "ar",
}: {
  children: ReactNode;
  defaultLocale?: AppLocale;
}) {
  const [locale, setLocaleState] = useState<AppLocale>(defaultLocale);

  // قراءة تفضيل محفوظ محليًا (إن وجد) بعد التحميل الأول فقط، لتفادي
  // اختلاف بين render الخادم والعميل (hydration mismatch).
  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(STORAGE_KEY);
      if (saved === "ar" || saved === "en") {
        setLocaleState(saved);
      }
    } catch {
      // localStorage قد يكون غير متاح (وضع خاص)، نتجاهل بأمان
    }
  }, []);

  const direction = DIRECTION_BY_LOCALE[locale];

  useEffect(() => {
    document.documentElement.setAttribute("dir", direction);
    document.documentElement.setAttribute("lang", locale);
  }, [direction, locale]);

  const setLocale = (next: AppLocale) => {
    setLocaleState(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, next);
    } catch {
      // تجاهل بأمان
    }
  };

  return (
    <DirectionContext.Provider value={{ locale, direction, setLocale }}>
      {children}
    </DirectionContext.Provider>
  );
}

export function useDirection(): DirectionContextValue {
  const ctx = useContext(DirectionContext);
  if (!ctx) {
    throw new Error("useDirection must be used within a DirectionProvider");
  }
  return ctx;
}
