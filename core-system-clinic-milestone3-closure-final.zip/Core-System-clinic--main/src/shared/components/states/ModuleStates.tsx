// src/shared/components/states/ModuleStates.tsx
// Milestone 3 Closure — بند 12 (Error/Empty/Loading states).
// نمط مشترك واحد بدل مكونات متكررة لكل وحدة. لا يستبدل أي منطق عمل قائم؛
// يُستدعى داخل الحالات الثلاث (isLoading / isError / بيانات فارغة) في كل وحدة.
//
// الاستخدام النموذجي داخل مكوّن وحدة:
//
//   if (isLoading) return <ModuleLoadingState label="جارٍ تحميل المرضى..." />;
//   if (isError) return <ModuleErrorState message={error.message} onRetry={refetch} />;
//   if (items.length === 0) return <ModuleEmptyState title="لا يوجد مرضى بعد" />;

import { AlertTriangle, Inbox, Loader2, type LucideIcon } from "lucide-react";
import { cn } from "@/shared/utils/cn";

interface ModuleLoadingStateProps {
  label?: string;
  className?: string;
}

export function ModuleLoadingState({ label = "جارٍ التحميل...", className }: ModuleLoadingStateProps) {
  return (
    <div
      className={cn("flex flex-col items-center justify-center gap-3 py-16 text-gray-500", className)}
      role="status"
      aria-live="polite"
    >
      <Loader2 className="h-6 w-6 animate-spin" aria-hidden="true" />
      <p className="text-sm">{label}</p>
    </div>
  );
}

interface ModuleEmptyStateProps {
  title: string;
  description?: string;
  icon?: LucideIcon;
  action?: React.ReactNode;
  className?: string;
}

export function ModuleEmptyState({
  title,
  description,
  icon: Icon = Inbox,
  action,
  className,
}: ModuleEmptyStateProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-gray-200 py-16 px-4 text-center",
        className
      )}
    >
      <Icon className="h-8 w-8 text-gray-300" aria-hidden="true" />
      <p className="text-sm font-medium text-gray-700">{title}</p>
      {description && <p className="text-sm text-gray-500 max-w-sm">{description}</p>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

interface ModuleErrorStateProps {
  message?: string;
  onRetry?: () => void;
  className?: string;
}

export function ModuleErrorState({
  message = "حدث خطأ أثناء تحميل البيانات.",
  onRetry,
  className,
}: ModuleErrorStateProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center gap-3 rounded-lg border border-red-100 bg-red-50 py-16 px-4 text-center",
        className
      )}
      role="alert"
    >
      <AlertTriangle className="h-8 w-8 text-red-400" aria-hidden="true" />
      <p className="text-sm text-red-700">{message}</p>
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="mt-1 rounded-md border border-red-200 bg-white px-3 py-1.5 text-sm text-red-700 hover:bg-red-50"
        >
          إعادة المحاولة
        </button>
      )}
    </div>
  );
}
