// src/app/layout.tsx
// Root layout — required by Next.js App Router.

import type { Metadata } from "next";
import { Toaster } from "sonner";
import { QueryClientProvider } from "@/shared/components/QueryClientProvider";
import { DirectionProvider } from "@/shared/i18n/DirectionProvider";
import "./globals.css";

export const metadata: Metadata = {
  title: "ClinicSaaS",
  description: "ClinicSaaS Multi-Tenant Platform",
};

// ملاحظة (Milestone 3 Closure — RTL/LTR): dir/lang الفعليان يُضبطان ديناميكيًا من
// DirectionProvider على عنصر <html> بعد التحميل (انظر src/shared/i18n/DirectionProvider.tsx).
// القيم هنا هي fallback أولي فقط قبل تفعيل JS (لتفادي وميض غير منسق للاتجاه).
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl">
      <body>
        <DirectionProvider defaultLocale="ar">
          <QueryClientProvider>
            {children}
          </QueryClientProvider>
          <Toaster />
        </DirectionProvider>
      </body>
    </html>
  );
}
