// Milestone 3 Closure — حل جذري (Next.js App Router loading.tsx) بدل حلول متفرقة داخل كل مكوّن.
import { ModuleLoadingState } from "@/shared/components/states/ModuleStates";

export default function Loading() {
  return <ModuleLoadingState label="جارٍ تحميل المرضى..." className="p-8" />;
}
