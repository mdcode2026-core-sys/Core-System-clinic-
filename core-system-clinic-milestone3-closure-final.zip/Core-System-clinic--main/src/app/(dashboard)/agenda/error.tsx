"use client";
// Milestone 3 Closure — حل جذري (Next.js App Router error.tsx) يمنع الشاشة البيضاء
// عند أي خطأ غير متوقع في هذا المسار، مع خيار إعادة المحاولة.
import { useEffect } from "react";
import { ModuleErrorState } from "@/shared/components/states/ModuleStates";

export default function RouteError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[route-error]", error);
  }, [error]);

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <ModuleErrorState message="حدث خطأ غير متوقع أثناء تحميل هذه الصفحة." onRetry={reset} />
    </div>
  );
}
