# PROJECT_HANDOFF.md

**Project:** CORE SYSTEM — ClinicSaaS™
**Purpose:** Single, living handoff document. Updated in place going forward — supersedes dated snapshot files (`Handoff_Daily_Report_2026-07-29.md`, `QUEUE_DEBUG_PROGRESS.md`, `QUEUE_FIX_PROGRESS.md`, `ANALYTICS_BUILD_PROGRESS.md`), which are archived under `/archive/` for historical reference.
**Last Updated:** 2026-08-08

---

**Note (2026-08-02):** `xalkair@gmail.com` and `yazeed48@gmail.com` are designated test accounts (real email addresses, test purpose). Roles/permissions on these two may be freely reassigned during verification without asking the Owner each time.

**Note (2026-08-04, Owner-confirmed product decision):** `doctor` role is intentionally read-only on `patients` (view list + view data only — no create/update/delete). Clinical data updates by doctors happen via `sessions:update` on `clinic_visit_sessions` (doctor_notes/clinical_notes), a separate table doctor already has write access to — patient master/administrative data is reception/admin territory by design. `clinic_admin` additionally has `patients:delete`. This supersedes the original Session 1 mapping for these two specific grants; not an error, do not revert.

## 1. Current State (as of this update)

| Area | Status |
|---|---|
| Core Foundation (auth, multi-tenancy, dashboard shell, analytics engine) | ✅ Closed |
| Patients | ✅ Closed |
| Agenda (Appointments) | 🟡 ~85% |
| Queue | 🟡 ~85% — see Open Item #1 below |
| Invoicing (Billing) | ✅ Closed |
| Analytics Engine | ✅ Closed (2026-07-30) |
| Inventory | ⚠️ Consumption log only (`inventory_ledger`); no stock/catalog model |
| Reports | ✅ Implemented (Package 3.1.7, 2026-08-04) — 18 reports across 6 modules, `reportRegistry.ts`/`reports.queries.ts`/`reports-shell.tsx`/`report-viewer.tsx` all present and wired. **This row was stale** — contradicted the CHANGELOG's own 2026-08-04 entry; corrected 2026-08-08. |
| Follow-up | ✅ Implemented — `src/domain/followup/followup.queries.ts` (list/scheduled/update-status) + `src/features/followup/{followup-shell,followup-list-view,followup-scheduled-view}.tsx` all present, non-trivial (370+ lines UI). **This row was stale** (said "no domain layer or UI"); corrected 2026-08-08. Exact completion date not established from available records — flag for Owner if it matters.
| Dashboard (Unified Workspace) | 🟡 Session 11 build blockers fixed 2026-08-08 (see Open Item #9) — code-complete pending real `npm run build` verification, not yet re-deployed |
| Permission Engine (dynamic, per ADR-001) | 🟡 Runtime complete (Package 3.0.1, 2026-08-02) — DB populated, permissionEngine.ts + usePermissions.ts live, build green. Navigation/UI wiring next (Package 3.0.2). |
| Tenant Administration Center / Settings Dashboard | Not started |

Authoritative next milestone: **Milestone 3 — Unified Workspace** (confirmed 2026-07-31, see ADR-002 in `ARCHITECTURE_DECISIONS.md`).

---

## 2. Open Items Requiring Attention

### Open Item #9 — Session 11 (Workspace) Recovery — code fixed, build not yet re-verified live (2026-08-08)
Session 11 had never reached a successful build. Direct repository + Vercel build log + live Supabase inspection identified the actual chain of failures (not guessed): a Promise passed where `resolveWidgetVisibility` expected a synchronous boolean (rejected by `tsconfig strict:true`), then — once that was fixed and the build progressed further than ever before — a missing `sonner` dependency, a Server/Client boundary violation in `invoicing.queries.ts`, and a root `layout.tsx` that was a mistaken verbatim copy of `(dashboard)/layout.tsx` (missing `<html>`/`<body>`, wrapping even public `/login` in an auth guard). All fixed directly; see `CHANGELOG.md` 2026-08-08 entry for the full file-by-file list.

**Also found and fixed in the same pass, not limited to the 5 Session 11 widget files:**
- `AuthProvider` (`src/core/auth/AuthProvider.tsx`) was fully implemented but never mounted anywhere — 6 real components (`patient-form`, `patient-list`, `MyQueueView`, `LiveQueueBoard`, `AmbientKioskView`, `AnalyticsDashboard`) call `useAuth()` and would throw at render. Now mounted in `(dashboard)/layout.tsx`.
- `user_metadata.tenant_id` (the exact anti-pattern `analytics.actions.ts` already warns against in a code comment) was still in use in 12 places project-wide, not just the 5 Session 11 widgets — 4 dashboard route pages and 3 domain query/action files. Consolidated onto a shared `resolveTenantId()`/`useTenantId()` resolver reading `clinic_users`.
- `feature_flags` seed (2026-08-04, Package 3.1.7) covered only 6 of the 8 module keys `WORKSPACE_ARCHITECTURE_SPECIFICATION.md` §9 documents — `analytics` and `reports` were missing, silently hiding the Analytics widget for every tenant regardless of subscription. Seeded via `supabase/migrations/20260808_seed_analytics_reports_feature_flags.sql`, same pattern as the existing 6 rows.

**Found stale, corrected in `DATABASE_SCHEMA.md`:** that document claimed `role_permissions` was empty (0 rows, never populated) — a live query found 89 rows. The document itself was out of date, not the system; corrected in place.

**Not fixed — flagged, needs an Owner/Architect decision, not mechanical:** `src/infrastructure/supabase/server.ts` still resolves the RLS tenant context (`set_tenant_id` RPC) from `user_metadata`/`app_metadata` internally rather than `clinic_users`. This function is imported by 19+ files across the whole app (effectively every server action) — correcting it touches the RLS-setting mechanism for the entire application, not an isolated fix. Until decided, any user whose JWT metadata has drifted from `clinic_users.tenant_id` risks RLS being applied under the wrong tenant context (or none).

**Still unverified — the actual blocker to closing this item:** ~~`npm run build` / `npm run lint` have not been run against these changes in a real Node environment~~ **RESOLVED (2026-08-08, same day):** the Owner's team ran a real `npm run build` in a GitHub Codespace. First attempt failed (stale files from an earlier partial copy — a local `mkdir -p`/`cp` sequencing issue, not a code defect); second attempt, after re-copying all files correctly, **succeeded.** Five additional issues were found and fixed in that pass — a missing `QueryClientProvider` mount (every new `react-query` hook added in this recovery would have thrown at runtime), an RTL regression introduced and same-day corrected, a nav-icon rendering bug in `WorkspaceShell.tsx`, a field-name mismatch in `QuickRegistrationWidget.tsx` this Architect's manual review had incorrectly cleared, and an unresolved `widgetRegistry.ts` moduleKey conflict (see below). Full detail in `CHANGELOG.md`, addendum to the 2026-08-08 entry. `npm run lint` has still not been confirmed run.

**New open decision point, found 2026-08-08 during the real build pass:** `src/core/workspace/widgetRegistry.ts`'s Analytics widget `moduleKey` was changed back to `ADVANCED_ANALYTICS`, reversing this recovery's earlier fix (which had set it to `analytics`, per `WORKSPACE_ARCHITECTURE_SPECIFICATION.md` §9, and seeded a matching `analytics` row into `feature_flags`). Both values now technically work (both rows exist in `feature_flags`), but they gate different things conceptually — `analytics` per §9's module list vs. `ADVANCED_ANALYTICS` per ADR-003's separate Add-on/License-tier layer. **Not resolved either way; flagged for the Owner.**

### Open Item #8 — Deep audit across Sessions 3–7 (2026-08-04)
Full direct repository + live database inspection performed after Kimi self-reported cascading failures in Session 6.

**Session 4 (Inventory) — CRITICAL, found and fixed live:** `rls_inventory_items_insert`/`update` policies were missing the `tenant_id = get_current_tenant_id()` check entirely (role-only check) — any `clinic_admin`/`receptionist`/`accounting` user could write to **any tenant's** inventory rows. `adjust_inventory_stock()` was `SECURITY DEFINER` with no internal permission check, callable by any authenticated user regardless of role, fully bypassing RLS. **Both fixed directly against the live database** (policies now include tenant_id; function changed to `SECURITY INVOKER`). The edit-save bug and dead-code issues from the prior review are confirmed fixed in the current committed files. **Process gap:** the committed migration file (`20260804000000_inventory_items_and_ledger_fk.sql`) was overwritten with unrelated later content (transaction-type constraint changes) and no longer reflects the actual live policy/function definitions — repository and live database have drifted. A reconciling migration capturing current live state should be committed.

**Session 6 (Queue) — one real unresolved bug, architectural fix specified:** `isDoctorView = canUpdateSession` incorrectly shows the doctor-only view (`MyQueueView`) to any role with `sessions:update`, which includes `clinic_admin` (not just `doctor`) — confirmed via Session 1's role_permissions. View *selection* (which screen layout renders) is not the same concern as action *permission* (what's clickable within it); use `role === "doctor"` (already available from `clinic_users`) to choose the view, while `usePermissions()` continues to gate individual actions inside each view. The prop-mismatch chaos Kimi self-reported across multiple attempts is no longer present in the current committed files — verified directly, `queue/page.tsx` / `MyQueueView.tsx` / `LiveQueueBoard.tsx` are structurally consistent now.

**Session 7 (Invoicing) — no issues found**, permission wiring follows established pattern correctly.

**Session 3 (Patients) — no new issues found** in spot re-check.

**Note on Kimi's Session 6 self-report:** it contains one factual error worth correcting for the record — `getEffectivePermissions()` reads from the database (`clinic_users`→`roles`→`role_permissions`→`permissions`), not from `permissionMatrix.ts` as the report claimed. The actual bug found (view-selection logic) is real and correctly identified despite this mischaracterization of the cause.

### Open Item #1 — `/queue` page status unconfirmed
**History:** `/queue` redirected to `/login` due to a missing `clinic_patients.file_number` column (root cause captured verbatim in the archived `Handoff_Daily_Report_2026-07-29.md`, task `TASK-QUEUE-DEBUG-001`). A fix was applied same-day (`TASK-QUEUE-FIX-002`, per archived `QUEUE_FIX_PROGRESS.md`).
**Verified true by this audit (2026-07-31):**
- The `file_number` column **exists live** on `clinic_patients` (confirmed via direct schema inspection) and the matching migration `20260729120000_add_file_number_to_clinic_patients.sql` is committed.
- `database.types.ts` **does** include `file_number` (confirmed) — contradicts `QUEUE_FIX_PROGRESS.md`, which still listed this as PENDING; that file was stale.
**Still unverified:** whether `/queue` actually loads successfully end-to-end in the deployed app (`QUEUE_FIX_PROGRESS.md` steps 6.4–6.6 — build/deploy check, live verification, and formal closure — were never marked done). **Action needed: a manual load test of `/queue` with an authenticated session, then formally close this item.**

### Open Item #2 — Security hotfixes: Phases A/B/D applied and verified; Phase C still pending
**Update (2026-08-01):** Phases A/B/D from `SECURITY_HOTFIX_MIGRATION.sql` were applied directly to the live database by the Architect on 2026-07-31, using `execute_sql` rather than the blocked `apply_migration` path. **First attempt silently failed verification** — `REVOKE ... FROM anon, authenticated` had no effect because Postgres grants `EXECUTE` to the implicit `PUBLIC` role by default at function creation, and `anon`/`authenticated` still inherited access through that. Corrected by revoking from `PUBLIC` directly and re-granting only to the intended roles (`authenticated`/`service_role` where needed, none for the fully-locked-down debug functions). Re-verified against live grants: confirmed `anon` no longer has `EXECUTE` on any of the flagged functions, while `authenticated` retains exactly what Patients/Agenda/Analytics depend on. **Phase C (`subscription_plans` read policy) remains pending an Owner decision and does not block other work.**

### Open Item #6 — `service_role` key committed to git history (accepted risk, tracked)
**Found:** 2026-08-01. `.env.local`, containing the real `SUPABASE_SERVICE_ROLE_KEY` (full RLS bypass), is tracked in git history (first committed alongside `PRODUCT_COMPLETION_ROADMAP_V2.md`). `.gitignore` lists `.env.local` but this does not retroactively untrack an already-committed file.
**Owner decision (2026-08-01):** known and accepted for now — needed for current work procedures, project is pre-production with no real tenant data yet. **Hard condition, not optional: this key must be rotated in the Supabase dashboard and the file untracked (`git rm --cached`) before any real tenant data or production launch — whichever comes first.** Re-raise this explicitly at the start of any production-readiness (Milestone 7) or go-live discussion.

**2026-08-09 re-classification — this is no longer purely a historical/accepted risk.** A direct download of the current `main` branch (public repository) still contains `.env.local` with the live key, confirming it is **currently tracked, not only present in old history**. The repository is public. **Status raised from "accepted risk" to active blocker.** `.env.local` has been removed from the working copy of this audit and rotation instructions issued separately (see Milestone 3 Closure final report, 2026-08-09) — key rotation itself is a manual Supabase Dashboard action still pending as of this entry; git history purge is pending a human Codespaces assistant per the same report.

### Open Item #7 — Build verification, partial (2026-08-01)
The Architect cloned the repository directly and ran `npx tsc --noEmit`: **zero TypeScript errors, confirmed.** Full `next build` could not be completed in the Architect's sandbox — it failed only on fetching the Inter font from Google Fonts (a network restriction in that environment, not a code defect); this is not evidence of a real build failure. `next lint` hit a CLI/config resolution issue in the same sandbox, inconclusive — not yet confirmed clean. Kimi has no execution access at all (confirmed via Kimi's own Session 0 report) and cannot verify any of this independently — the Architect is the verification path for build/type-check results going forward, relayed through the Owner.

**2026-08-09 root cause found:** the `next lint` failure was not environmental — `next lint` was removed entirely in Next.js 16 (project is on 16.2.10), and ESLint 9 (`^9.25.1`) requires flat config by default with no `eslint.config.js`/`.mjs` present, so `.eslintrc.json` was not being read regardless. Fixed: added `eslint.config.mjs` (via `FlatCompat`, wrapping the existing `next/core-web-vitals` rules unchanged) and updated `package.json`'s `lint` script to `eslint .`. **Still open:** the corrected command has not actually been run yet (no Node/npm execution environment available for this audit) — must be run in Codespaces/CI to confirm zero violations before Milestone 3 can be called fully verified.

### Open Item #3 — Legacy tenant tables not formally resolved
`tenants`, `users`, `subscriptions`, `subscription_events` (see ADR-000) still exist live with residual data, superseded since 2026-07-29 but never formally deprecated or dropped. No action taken yet; flagged for a future decision.

**2026-08-09 update:** these are not purely dormant — see ADR-000 update in `ARCHITECTURE_DECISIONS.md`: the `on_auth_user_created` trigger on `auth.users` (`handle_new_user()`) actively reads `public.users` on every login/signup. Verified currently harmless for the one real matching account, but fragile. Not fixed this milestone per owner instruction (legacy tables kept, not modified) — documented so the active read path isn't lost to history again.

### Open Item #4 — Documentation consolidation in progress
See `DOCUMENTATION_CONSOLIDATION_PLAN.md`. `ARCHITECTURE_DECISIONS.md` and `DATABASE_SCHEMA.md` have been created. `MASTER_ROADMAP.md` (renamed/merged from `PRODUCT_COMPLETION_ROADMAP_V2.md`) and this file are being produced in the same pass. Archiving of superseded files has not been executed yet — plan only, pending approval.

### Open Item #5 — EN-001: Milestone 2 (Tenant Administration Center) roadmap content missing
Sections 8–16 of the roadmap, which almost certainly specify Milestone 2, are absent even from the canonical repository copy of `PRODUCT_COMPLETION_ROADMAP_V2.md`. Not yet resolved.

---

## 3. Known Issues Register (consolidated from `CORE_SYSTEM_INDEX.md` "Current Known Problems," 11 issues total)

| # | Issue | Status |
|---|---|---|
| 001 | Dashboard routing — correct route is `src/app/(dashboard)/page.tsx`, not `.../dashboard/page.tsx` | ✅ Resolved |
| 002 | Repeated proposal of already-failed solutions | Process rule, not a bug — see `ENGINEERING_CONSTITUTION.md` |
| 003 | Blind file modification without dependency analysis | Process rule — same |
| 004 | Console/browser-devtools dependency (Owner develops from mobile) | Process rule — prefer server-side diagnostics |
| 005 | Artificial/temporary file creation | Process rule |
| 006 | RLS bugs in `rls_sessions_write_role_check`, `rls_invoices_doctor_read`, `rls_audit_read` | ✅ Resolved |
| 007 | Legacy tables (`users`/`clinic_users`, `tenants`/`master_tenants`) inconsistency | ✅ Resolved (app-layer only — legacy tables still physically present, see ADR-000) |
| 008 | `isDoctor` manually hardcoded to `false` in `queue/page.tsx` | 🟡 Suspended — waiting on `MyQueueView` |
| 009 | Analytics build error chain (dead import, `"use server"` misuse, unsupported locale glyphs) | ✅ Resolved |
| **010** | **`/queue` redirect to `/login`, missing `file_number` column** | **Still officially OPEN per `CORE_SYSTEM_INDEX.md` as of 2026-07-30 — matches Open Item #1 above. The column now exists (verified), but formal closure/live verification never happened.** |
| 011 | `@types/react` peer dependency warning (18.x vs 19.x) | Cosmetic, non-blocking |

**Production status:** Not yet in production (`Production: NO` per `CORE_SYSTEM_INDEX.md`).

---

## 4. Historical Record (condensed from archived daily reports)

**2026-07-29 — TASK-SIGNUP-001:** Fixed sign-up flow so `tenant_id`/`role` are correctly written to both `user_metadata` and `app_metadata` after `create_tenant_with_subscription` succeeds (previously the `handle_new_user` trigger fired too early to have this data). `create_tenant_with_subscription` was rewritten to stop writing to the legacy tables (see ADR-000) and write only to `master_tenants`/`clinic_users`. Verified working end-to-end for Dashboard and Invoices; Queue was found broken (see Open Item #1's history).

**2026-07-29 — TASK-QUEUE-DEBUG-001:** Diagnostic task. Reverted an unauthorized modification to `get_current_user_role()` made during the prior task's troubleshooting. **Found and fixed a genuine tenant-isolation risk:** `set_tenant_id()` was using `set_config(..., false)` — database-connection-wide scope — instead of `true` (transaction-local). Under Supabase's connection pooling, this could have let one request's tenant context leak into another pooled connection. Corrected to `true`. Root-caused the `/queue` failure precisely to the missing `file_number` column via a temporary, then fully reverted, debug patch.

**2026-07-29 — TASK-QUEUE-FIX-002:** Added the `file_number` column. Migration and type-generation steps were left marked PENDING in the task log but are confirmed complete by this audit (Open Item #1).

**2026-07-30 — Analytics Engine (Phase 1A) closed.**

**2026-07-31 — This audit cycle:** Full repository + live database inspection performed. Findings: security exposures (see `SECURITY_AUDIT_REPORT.md`), confirmed the permission system architecture direction (ADR-001), confirmed Milestone 3 as current (ADR-002), and began documentation consolidation.
