// eslint.config.mjs
// Milestone 3 Closure — بند 16 (Lint).
//
// السبب: package.json كان يستخدم "next lint" التي حُذفت تمامًا من Next.js 16
// (كان المشروع على Next 16.2.10). كما أن ESLint 9 (^9.25.1 في devDependencies)
// يتطلب Flat Config افتراضيًا ولا يقرأ .eslintrc.json تلقائيًا. الحل القياسي
// الموثّق من Next.js نفسه: استخدام FlatCompat (موجودة أصلاً في devDependencies
// كـ @eslint/eslintrc) لتحويل تهيئة next/core-web-vitals القديمة إلى Flat Config،
// دون إعادة كتابة أي قاعدة يدويًا وبدون تغيير سلوك القواعد الحالية في .eslintrc.json.

import { dirname } from "path";
import { fileURLToPath } from "url";
import { FlatCompat } from "@eslint/eslintrc";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const compat = new FlatCompat({
  baseDirectory: __dirname,
});

const eslintConfig = [
  ...compat.extends("next/core-web-vitals"),
  {
    rules: {
      "react-hooks/exhaustive-deps": "warn",
      "no-console": ["warn", { allow: ["error", "warn"] }],
      "no-debugger": "error",
    },
  },
  {
    ignores: ["node_modules/**", ".next/**", "out/**", "dist/**"],
  },
];

export default eslintConfig;
