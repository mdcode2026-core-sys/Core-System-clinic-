-- M2.0 LIVE VERIFICATION SUITE
-- Run on Supabase SQL Editor after applying all 7 migrations

-- 1. clinic_users role constraint (7 values)
SELECT conname, pg_get_constraintdef(oid) 
FROM pg_constraint 
WHERE conrelid = 'clinic_users'::regclass AND contype = 'c' AND conname LIKE '%role%';
-- EXPECTED: CHECK (role IN ('super_admin','clinic_admin','clinic_owner','doctor','nurse','receptionist','accounting'))

-- 2. clinic_rooms.name removed
SELECT column_name 
FROM information_schema.columns 
WHERE table_name = 'clinic_rooms' AND column_name = 'name';
-- EXPECTED: 0 rows

-- 3. branches: one default per existing tenant
SELECT 
    COUNT(*) FILTER (WHERE is_default = true) as default_branches,
    COUNT(DISTINCT tenant_id) as tenant_count
FROM public.branches;
-- EXPECTED: default_branches = tenant_count

-- 4. create_tenant_with_subscription creates branch
SELECT prosrc FROM pg_proc WHERE proname = 'create_tenant_with_subscription';
-- MUST contain: INSERT INTO branches

-- 5. subscription_plans SELECT policy
SELECT polname, polcmd, polqual::text 
FROM pg_policy 
WHERE polrelid = 'subscription_plans'::regclass;
-- EXPECTED: rls_subscription_plans_read, FOR SELECT, USING (true)

-- 6. roles.tenant_id exists
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'roles' AND column_name = 'tenant_id';
-- EXPECTED: uuid, YES

-- 7. clinic_users.role_template_id exists
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'clinic_users' AND column_name = 'role_template_id';
-- EXPECTED: uuid, YES

-- 8. Partial uniqueness constraints
SELECT indexname, indexdef
FROM pg_indexes 
WHERE tablename = 'roles' AND (indexname LIKE '%system%' OR indexname LIKE '%custom%');
-- EXPECTED: idx_roles_system_unique (WHERE is_system_role = true)
-- EXPECTED: idx_roles_custom_unique (WHERE tenant_id IS NOT NULL)

-- 9. roles RLS: SELECT = system all + custom tenant-only
SELECT polname, polcmd, pg_get_expr(polqual, polrelid) as using_expr
FROM pg_policy 
WHERE polrelid = 'roles'::regclass AND polcmd = 'SELECT';
-- EXPECTED: is_system_role = true OR tenant_id = get_current_tenant_id()

-- 10. roles RLS: INSERT/UPDATE/DELETE = custom only
SELECT polname, polcmd, pg_get_expr(polqual, polrelid) as using_expr
FROM pg_policy 
WHERE polrelid = 'roles'::regclass AND polcmd IN ('INSERT','UPDATE','DELETE');
-- EXPECTED: is_system_role = false AND tenant_id = get_current_tenant_id()

-- 11. role_permissions RLS: SELECT = system all + custom tenant-only
SELECT polname, polcmd, pg_get_expr(polqual, polrelid) as using_expr
FROM pg_policy 
WHERE polrelid = 'role_permissions'::regclass AND polcmd = 'SELECT';
-- EXPECTED: EXISTS(... is_system_role = true OR tenant_id = get_current_tenant_id())

-- 12. role_permissions RLS: INSERT/UPDATE/DELETE = custom only
SELECT polname, polcmd, pg_get_expr(polqual, polrelid) as using_expr
FROM pg_policy 
WHERE polrelid = 'role_permissions'::regclass AND polcmd IN ('INSERT','UPDATE','DELETE');
-- EXPECTED: EXISTS(... is_system_role = false AND tenant_id = get_current_tenant_id())

-- 13. Notification prefs table
SELECT COUNT(*) FROM public.tenant_notification_channel_prefs;
-- EXPECTED: 0

-- 14. M2 permissions exist
SELECT permission_key FROM public.permissions 
WHERE permission_key IN ('roles:read','roles:manage','templates:manage','overrides:manage','subscription:read','notifications:manage')
ORDER BY permission_key;
-- EXPECTED: 6 rows

-- 15. M2 perms assigned to super_admin and clinic_admin ONLY
SELECT r.role_key, COUNT(rp.id) as m2_count
FROM public.roles r
JOIN public.role_permissions rp ON r.id = rp.role_id
JOIN public.permissions p ON p.id = rp.permission_id
WHERE p.permission_key IN ('roles:read','roles:manage','templates:manage','overrides:manage','subscription:read','notifications:manage')
AND r.role_key IN ('super_admin', 'clinic_admin')
GROUP BY r.role_key;
-- EXPECTED: super_admin = 6, clinic_admin = 6

-- 16. NO other roles have M2 permissions
SELECT r.role_key, p.permission_key
FROM public.roles r
JOIN public.role_permissions rp ON r.id = rp.role_id
JOIN public.permissions p ON p.id = rp.permission_id
WHERE p.permission_key IN ('roles:read','roles:manage','templates:manage','overrides:manage','subscription:read','notifications:manage')
AND r.role_key NOT IN ('super_admin', 'clinic_admin');
-- EXPECTED: 0 rows

-- 17. Existing 34 RLS policies UNMODIFIED
SELECT COUNT(*) as total_policies 
FROM pg_policy 
WHERE polrelid NOT IN (
    'roles'::regclass, 
    'role_permissions'::regclass, 
    'subscription_plans'::regclass, 
    'branches'::regclass, 
    'tenant_notification_channel_prefs'::regclass
);
-- EXPECTED: 34

-- 18. System roles are READ-ONLY
SELECT COUNT(*) 
FROM pg_policy 
WHERE polrelid = 'roles'::regclass 
AND polcmd IN ('INSERT','UPDATE','DELETE')
AND polqual::text LIKE '%is_system_role = true%';
-- EXPECTED: 0

-- 19. System role_permissions are READ-ONLY
SELECT COUNT(*) 
FROM pg_policy 
WHERE polrelid = 'role_permissions'::regclass 
AND polcmd IN ('INSERT','UPDATE','DELETE')
AND polqual::text LIKE '%is_system_role = true%';
-- EXPECTED: 0

-- 20. TENANT ISOLATION TEST: Custom role from Tenant A invisible to Tenant B
-- (Requires manual test with two tenant accounts)
